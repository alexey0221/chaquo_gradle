data class FileItem(val name: String)
