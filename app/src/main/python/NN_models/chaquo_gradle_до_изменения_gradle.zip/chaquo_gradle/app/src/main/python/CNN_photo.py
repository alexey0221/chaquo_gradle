from PIL import Image
import torch
# import torchvision.transforms as transforms
import numpy as np
from com.chaquo.python import Python
context = Python.getPlatform().getApplication()

def photoFindText(image_path):
    CNN_path = "python/NN_models/model_cnn_photo_classification_GPU_reshape_without_print.pt"
    # Открываем изображение с помощью библиотеки Pillow
    img = Image.open(image_path)
    resized_img = img.resize((200, 200))
    resized_img = np.array(resized_img)
    desired_shape = np.array([200, 200, 3])
    if not np.array_equal(resized_img.shape, desired_shape):
        # print("Error")
        return torch.tensor([-1.0], requires_grad=True)
    # print(f'resized_img.shape = {resized_img.shape}')

    tensorImg = torch.empty(1, 200, 200, 3)
    tensorImg[0] = torch.tensor(resized_img)
    tensorImg = tensorImg / 255

    tensorImg = tensorImg.permute(0, 3, 1, 2)

    # cnn = CNNet()

    # cnn.load_state_dict(torch.load('NN_models/cnn_model_weight.pth',map_location=torch.device('cpu')))
    # cnn.eval()
    # preds = cnn.forward(tensorImg)
    model_photo = torch.jit.load(CNN_path,map_location=torch.device('cpu'))
    model_photo.eval()
    # print(tensorImg.shape)
    confidence = model_photo(tensorImg)
    # print(f'confidence.shape: {confidence.shape}')
    # confidence = cnn(tensorImg)
    # print(f'Предсказание модели confidence: {confidence}')
    # print(f'Предсказание модели preds: {preds}')
    return confidence