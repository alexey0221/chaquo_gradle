package com.example.chaquo_gradle

import FileAdapter
import FileItem
import android.os.Bundle
import android.os.Environment
import android.os.Environment.getExternalStoragePublicDirectory
import android.widget.Button
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import java.io.File

class MainActivity : AppCompatActivity() {

    private lateinit var fileAdapter: FileAdapter
    private val PERMISSION_STORAGE = 101

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        initPython()
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        if (!PermissionUtils.hasPermissions(this))
            PermissionUtils.requestPermissions(this, PERMISSION_STORAGE);

        val myFilesDir = File(this.filesDir, "my_files")
        if (!myFilesDir.exists()) {
            // Create the directory
            myFilesDir.mkdir()
        }
//        val files = myFilesDir.listFiles()?.map { FileItem(it.name) } ?: emptyList()
        val but = findViewById<Button>(R.id.button)
        val text = findViewById<TextView>(R.id.textView)
        but.setOnClickListener {
            text.text = getHelloPy("Alex_123")
        }
        getListFromMyFiles()

        val sortImg = findViewById<Button>(R.id.sort_img)
        sortImg.setOnClickListener {
            val downloadDir =
                File(getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).absolutePath)
            val photoFiles = File(downloadDir, "photos")
            photoFiles.listFiles()?.forEach { file ->
                if (file.extension in listOf("jpg", "jpeg", "png", "gif")) {
                    val predict =
                        PyPhotoFindText(File(photoFiles.toString(), file.name).absolutePath)
                    if (predict < 0.5) {
                        file.copyTo(
                            File(
                                File(this.filesDir, "my_files"),
                                file.name
                            )
                        ) // переносим файлы с расширением фотографий в новую папку
                        file.delete() // удаляем исходный файл
                    }
                }
            }
            getListFromMyFiles()
        }
//        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
//            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
//            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
//            insets
//        }
    }
    private fun initPython() {
        if (!Python.isStarted()) {
            Python.start(AndroidPlatform (this));
        }
    }
    private fun getHelloPy(name:String):String{ // Получение функции написанной на Python
        val python = Python.getInstance()
        val pythonFile = python.getModule("test")
        return pythonFile.callAttr("test", name).toString()
    }
    private fun getListFromMyFiles(){
        //Получение названия файлов из Download
//        val downloadDir =
//            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
//        val files = downloadDir.listFiles()?.map { FileItem(it.name) } ?: emptyList()
        val myFilesDir = File(this.filesDir, "my_files")
        val files = myFilesDir.listFiles()?.map { FileItem(it.name) } ?: emptyList()
        // Формирование RecicleView и вывод его содержимого
        fileAdapter = FileAdapter(files)
        val recyclerViewFiles = findViewById<RecyclerView>(R.id.recyclerViewFiles)
        recyclerViewFiles.apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = fileAdapter
        }
    }

}