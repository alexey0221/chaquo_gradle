//import android.R
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
//import com.example.protection.R
//import com.example.chaquo_gradle.R

class FileAdapter(private val files: List<FileItem>) : RecyclerView.Adapter<FileAdapter.FileViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FileViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(com.example.chaquo_gradle.R.layout.item_file, parent, false)
        return FileViewHolder(view)
    }

    override fun onBindViewHolder(holder: FileViewHolder, position: Int) {
        val file = files[position]
        holder.bind(file)
    }

    override fun getItemCount(): Int {
        return files.size
    }

    class FileViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val textViewFileName: TextView = itemView.findViewById(com.example.chaquo_gradle.R.id.documentNameTextView)
        val deleteButton = itemView.findViewById<View>(com.example.chaquo_gradle.R.id.deleteButton)
        val sendButton = itemView.findViewById<View>(com.example.chaquo_gradle.R.id.sendButton)
        fun bind(file: FileItem) {
            textViewFileName.text = file.name


            deleteButton.setOnClickListener(View.OnClickListener {
                // обработка нажатия на кнопку удаления
                val position = adapterPosition
                // выполнение действий по удалению файла на позиции position
            })

            sendButton.setOnClickListener(View.OnClickListener {
                // обработка нажатия на кнопку отправки
                val position = adapterPosition
                // выполнение действий по отправке файла на позиции position
            })
        }
    }
}
