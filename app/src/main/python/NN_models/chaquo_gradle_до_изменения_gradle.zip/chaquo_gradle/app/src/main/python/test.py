def test(name):
    return "Hello " + name